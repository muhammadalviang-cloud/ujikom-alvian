<?php

require __DIR__ . '/includes/init.php';

require_login();

$keyword = ambil_teks($_GET, 'q');
$daftar = barang_semua($koneksi, $keyword);

$judul = 'Data Barang';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h1 class="h4 mb-1">Data Barang</h1>
        <p class="text-secondary mb-0">Kelola daftar barang yang tersedia.</p>
    </div>
    <a href="barang_form.php" class="btn btn-primary">Tambah Barang</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="get" action="barang.php" class="row g-2 mb-3">
            <div class="col-12 col-sm-8 col-lg-6">
                <label for="q" class="visually-hidden">Cari barang</label>
                <input type="text" class="form-control" id="q" name="q" value="<?= e($keyword) ?>" placeholder="Cari kode, nama, atau kategori">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary">Cari</button>
            </div>
            <?php if ($keyword !== ''): ?>
                <div class="col-auto">
                    <a href="barang.php" class="btn btn-outline-secondary">Reset</a>
                </div>
            <?php endif; ?>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th class="text-end">Harga</th>
                        <th class="text-end">Stok</th>
                        <th class="text-end">Nilai Stok</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($daftar)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">
                                <?= $keyword === '' ? 'Belum ada data barang.' : 'Barang tidak ditemukan.' ?>
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($daftar as $barang): ?>
                            <tr>
                                <td class="text-nowrap"><?= e($barang['kode']) ?></td>
                                <td><?= e($barang['nama']) ?></td>
                                <td><?= e($barang['kategori']) ?></td>
                                <td class="text-end text-nowrap"><?= format_rupiah($barang['harga']) ?></td>
                                <td class="text-end"><?= number_format((int) $barang['stok'], 0, ',', '.') ?></td>
                                <td class="text-end text-nowrap"><?= format_rupiah((int) $barang['harga'] * (int) $barang['stok']) ?></td>
                                <td class="text-end text-nowrap">
                                    <a href="barang_form.php?id=<?= (int) $barang['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <a href="barang_hapus.php?id=<?= (int) $barang['id'] ?>" class="btn btn-sm btn-outline-danger">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
