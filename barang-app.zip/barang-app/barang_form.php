<?php

require __DIR__ . '/includes/init.php';

require_login();

$errors = [];
$id = null;
$mode_edit = false;
$barang = null;

// Mode edit hanya aktif jika id valid dan datanya ditemukan.
if (isset($_GET['id'])) {
    $id = ambil_id($_GET['id']);

    if ($id === null) {
        set_flash('danger', 'ID barang tidak valid.');
        redirect('barang.php');
    }

    $barang = barang_cari_id($koneksi, $id);

    if ($barang === null) {
        set_flash('danger', 'Data barang tidak ditemukan.');
        redirect('barang.php');
    }

    $mode_edit = true;
}

$data = [
    'kode' => $barang !== null ? $barang['kode'] : '',
    'nama' => $barang !== null ? $barang['nama'] : '',
    'kategori' => $barang !== null ? $barang['kategori'] : '',
    'harga' => $barang !== null ? $barang['harga'] : '',
    'stok' => $barang !== null ? $barang['stok'] : '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tujuan = $mode_edit ? 'barang_form.php?id=' . $id : 'barang_form.php';

    if (!csrf_valid()) {
        set_flash('danger', 'Sesi tidak valid atau sudah kedaluwarsa. Silakan coba lagi.');
        redirect($tujuan);
    }

    $data = [
        'kode' => ambil_teks($_POST, 'kode'),
        'nama' => ambil_teks($_POST, 'nama'),
        'kategori' => ambil_teks($_POST, 'kategori'),
        'harga' => ambil_teks($_POST, 'harga'),
        'stok' => ambil_teks($_POST, 'stok'),
    ];

    $errors = validasi_barang($data, $koneksi, $id);

    if (empty($errors)) {
        $berhasil = $mode_edit
            ? barang_update($koneksi, $id, $data)
            : barang_tambah($koneksi, $data);

        if ($berhasil) {
            set_flash('success', $mode_edit ? 'Data barang berhasil diperbarui.' : 'Data barang berhasil ditambahkan.');
            redirect('barang.php');
        }

        $errors['umum'] = 'Data gagal disimpan. Periksa kembali kode barang.';
    }
}

$judul = $mode_edit ? 'Edit Barang' : 'Tambah Barang';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h1 class="h4 mb-1"><?= e($judul) ?></h1>
        <p class="text-secondary mb-0"><?= $mode_edit ? 'Ubah data barang yang sudah ada.' : 'Isi data barang yang akan ditambahkan.' ?></p>
    </div>
    <a href="barang.php" class="btn btn-outline-secondary">Kembali</a>
</div>

<div class="row">
    <div class="col-12 col-lg-8">
        <div class="card">
            <div class="card-body p-4">
                <?php if (isset($errors['umum'])): ?>
                    <div class="alert alert-danger" role="alert"><?= e($errors['umum']) ?></div>
                <?php endif; ?>

                <form method="post" action="barang_form.php<?= $mode_edit ? '?id=' . (int) $id : '' ?>" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="kode" class="form-label">Kode barang</label>
                        <input type="text" class="form-control<?= isset($errors['kode']) ? ' is-invalid' : '' ?>" id="kode" name="kode" value="<?= e($data['kode']) ?>" maxlength="20" required autofocus>
                        <?php if (isset($errors['kode'])): ?>
                            <div class="invalid-feedback"><?= e($errors['kode']) ?></div>
                        <?php else: ?>
                            <div class="form-text">Contoh: BRG-001. Maksimal 20 karakter.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama barang</label>
                        <input type="text" class="form-control<?= isset($errors['nama']) ? ' is-invalid' : '' ?>" id="nama" name="nama" value="<?= e($data['nama']) ?>" maxlength="150" required>
                        <?php if (isset($errors['nama'])): ?>
                            <div class="invalid-feedback"><?= e($errors['nama']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" class="form-control<?= isset($errors['kategori']) ? ' is-invalid' : '' ?>" id="kategori" name="kategori" value="<?= e($data['kategori']) ?>" maxlength="100" required>
                        <?php if (isset($errors['kategori'])): ?>
                            <div class="invalid-feedback"><?= e($errors['kategori']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="row g-3 mb-4">
                        <div class="col-12 col-sm-6">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="number" class="form-control<?= isset($errors['harga']) ? ' is-invalid' : '' ?>" id="harga" name="harga" value="<?= e($data['harga']) ?>" min="0" step="1" required>
                            <?php if (isset($errors['harga'])): ?>
                                <div class="invalid-feedback"><?= e($errors['harga']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-6">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" class="form-control<?= isset($errors['stok']) ? ' is-invalid' : '' ?>" id="stok" name="stok" value="<?= e($data['stok']) ?>" min="0" step="1" required>
                            <?php if (isset($errors['stok'])): ?>
                                <div class="invalid-feedback"><?= e($errors['stok']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><?= $mode_edit ? 'Simpan Perubahan' : 'Simpan' ?></button>
                        <a href="barang.php" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
