<?php

require __DIR__ . '/includes/init.php';

redirect(user_login() !== null ? 'dashboard.php' : 'login.php');
