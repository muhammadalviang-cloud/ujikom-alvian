<?php

require __DIR__ . '/includes/init.php';

require_login();

// Logout hanya boleh lewat POST yang memiliki token CSRF.
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) {
    set_flash('danger', 'Permintaan logout tidak valid.');
    redirect('dashboard.php');
}

logout_user();
redirect('login.php?logout=1');
