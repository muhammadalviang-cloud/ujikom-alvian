<?php

require __DIR__ . '/includes/init.php';

if (user_login() !== null) {
    redirect('dashboard.php');
}

$errors = [];
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        set_flash('danger', 'Sesi tidak valid atau sudah kedaluwarsa. Silakan coba lagi.');
        redirect('login.php');
    }

    $username = ambil_teks($_POST, 'username');
    $password = ambil_teks($_POST, 'password', false);
    $errors = validasi_login($_POST);

    if (empty($errors)) {
        $stmt = $koneksi->prepare('SELECT id, nama, username, password FROM users WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $pengguna = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($pengguna !== null && password_verify($password, $pengguna['password'])) {
            login_user($pengguna);
            set_flash('success', 'Selamat datang, ' . $pengguna['nama'] . '.');
            redirect('dashboard.php');
        }

        $errors['umum'] = 'Username atau password salah.';
    }
}

$judul = 'Masuk';
$halaman_auth = true;
require __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
    <div class="col-12 col-sm-9 col-md-7 col-lg-5">
        <div class="text-center mb-4">
            <a href="index.php" class="text-decoration-none text-dark">
                <span class="h4 fw-semibold">Data Barang</span>
            </a>
            <p class="text-secondary small mb-0">Masuk untuk mengelola data barang.</p>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h5 mb-3">Masuk</h1>

                <?php if (isset($_GET['logout']) && $_GET['logout'] === '1'): ?>
                    <div class="alert alert-info" role="alert">Anda telah keluar dari sistem.</div>
                <?php endif; ?>

                <?php if (isset($errors['umum'])): ?>
                    <div class="alert alert-danger" role="alert"><?= e($errors['umum']) ?></div>
                <?php endif; ?>

                <form method="post" action="login.php" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control<?= isset($errors['username']) ? ' is-invalid' : '' ?>" id="username" name="username" value="<?= e($username) ?>" autocomplete="username" required autofocus>
                        <?php if (isset($errors['username'])): ?>
                            <div class="invalid-feedback"><?= e($errors['username']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control<?= isset($errors['password']) ? ' is-invalid' : '' ?>" id="password" name="password" autocomplete="current-password" required>
                        <?php if (isset($errors['password'])): ?>
                            <div class="invalid-feedback"><?= e($errors['password']) ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Masuk</button>
                </form>

                <p class="text-center text-secondary small mt-4 mb-0">
                    Belum punya akun? <a href="register.php" class="text-decoration-none">Daftar</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
