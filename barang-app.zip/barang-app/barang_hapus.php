<?php

require __DIR__ . '/includes/init.php';

require_login();

$id = ambil_id($_GET['id'] ?? null);

if ($id === null) {
    set_flash('danger', 'ID barang tidak valid.');
    redirect('barang.php');
}

$barang = barang_cari_id($koneksi, $id);

if ($barang === null) {
    set_flash('danger', 'Data barang tidak ditemukan.');
    redirect('barang.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        set_flash('danger', 'Sesi tidak valid atau sudah kedaluwarsa. Silakan coba lagi.');
        redirect('barang_hapus.php?id=' . $id);
    }

    if (barang_hapus($koneksi, $id)) {
        set_flash('success', 'Data barang berhasil dihapus.');
    } else {
        set_flash('danger', 'Data barang gagal dihapus.');
    }

    redirect('barang.php');
}

$judul = 'Hapus Barang';
require __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-6">
        <div class="card">
            <div class="card-body p-4">
                <h1 class="h5 mb-3">Hapus Barang</h1>
                <p class="text-secondary">Data berikut akan dihapus permanen. Pastikan pilihan Anda sudah benar.</p>

                <dl class="row mb-4">
                    <dt class="col-4 col-sm-3">Kode</dt>
                    <dd class="col-8 col-sm-9"><?= e($barang['kode']) ?></dd>

                    <dt class="col-4 col-sm-3">Nama</dt>
                    <dd class="col-8 col-sm-9"><?= e($barang['nama']) ?></dd>

                    <dt class="col-4 col-sm-3">Kategori</dt>
                    <dd class="col-8 col-sm-9"><?= e($barang['kategori']) ?></dd>

                    <dt class="col-4 col-sm-3">Harga</dt>
                    <dd class="col-8 col-sm-9"><?= format_rupiah($barang['harga']) ?></dd>

                    <dt class="col-4 col-sm-3">Stok</dt>
                    <dd class="col-8 col-sm-9"><?= number_format((int) $barang['stok'], 0, ',', '.') ?></dd>
                </dl>

                <form method="post" action="barang_hapus.php?id=<?= (int) $id ?>" class="d-flex gap-2">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                    <a href="barang.php" class="btn btn-outline-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
