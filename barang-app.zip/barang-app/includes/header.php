<?php
$judul = isset($judul) ? $judul : 'Data Barang';
$halaman_auth = isset($halaman_auth) ? $halaman_auth : false;
$pengguna = user_login();
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> - Data Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">
<?php if (!$halaman_auth): ?>
<nav class="navbar navbar-expand-lg navbar-dark navbar-app">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Data Barang</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuUtama" aria-controls="menuUtama" aria-expanded="false" aria-label="Buka menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuUtama">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= menu_aktif('dashboard.php') ?>" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= menu_aktif('barang.php') ?>" href="barang.php">Data Barang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= menu_aktif('laporan.php') ?>" href="laporan.php">Laporan</a>
                </li>
            </ul>
            <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-2">
                <span class="text-white-50 small"><?= e($pengguna['nama'] ?? '') ?></span>
                <form method="post" action="logout.php" class="m-0">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-outline-light">Keluar</button>
                </form>
            </div>
        </div>
    </div>
</nav>
<?php endif; ?>
<main class="flex-grow-1 py-4">
    <div class="container">
        <?php tampilkan_flash(); ?>
