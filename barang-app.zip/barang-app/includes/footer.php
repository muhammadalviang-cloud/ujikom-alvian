    </div>
</main>
<footer class="border-top bg-white py-3 mt-auto">
    <div class="container text-center small text-secondary">
        Data Barang &copy; <?= date('Y') ?>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
