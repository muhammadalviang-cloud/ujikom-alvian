<?php

require __DIR__ . '/includes/init.php';

require_login();

$ringkasan = hitung_ringkasan($koneksi);
$terbaru = barang_terbaru($koneksi, 5);

$judul = 'Dashboard';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h1 class="h4 mb-1">Dashboard</h1>
        <p class="text-secondary mb-0">Ringkasan data barang saat ini.</p>
    </div>
    <a href="barang_form.php" class="btn btn-primary">Tambah Barang</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-label mb-1">Jumlah Barang</div>
                <div class="stat-value"><?= number_format($ringkasan['jumlah_barang'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-label mb-1">Total Stok</div>
                <div class="stat-value"><?= number_format($ringkasan['total_stok'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="stat-label mb-1">Total Nilai</div>
                <div class="stat-value"><?= format_rupiah($ringkasan['total_nilai']) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Barang Terbaru</span>
        <a href="barang.php" class="small text-decoration-none">Lihat semua</a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th class="text-end">Harga</th>
                    <th class="text-end">Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($terbaru)): ?>
                    <tr>
                        <td colspan="5" class="text-center text-secondary py-4">Belum ada data barang.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($terbaru as $barang): ?>
                        <tr>
                            <td class="text-nowrap"><?= e($barang['kode']) ?></td>
                            <td><?= e($barang['nama']) ?></td>
                            <td><?= e($barang['kategori']) ?></td>
                            <td class="text-end text-nowrap"><?= format_rupiah($barang['harga']) ?></td>
                            <td class="text-end"><?= number_format((int) $barang['stok'], 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
