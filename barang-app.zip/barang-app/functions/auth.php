<?php

function user_login()
{
    return isset($_SESSION['user']) ? $_SESSION['user'] : null;
}

function login_user(array $user)
{
    session_regenerate_id(true);

    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'nama' => $user['nama'],
        'username' => $user['username'],
    ];
}

function logout_user()
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => isset($params['samesite']) ? $params['samesite'] : 'Lax',
        ]);
    }

    session_destroy();
}

function require_login()
{
    if (user_login() === null) {
        redirect('login.php');
    }
}
