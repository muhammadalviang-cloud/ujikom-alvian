<?php

// Ringkasan dihitung langsung dari database.
function hitung_ringkasan(mysqli $koneksi)
{
    $hasil = $koneksi->query(
        'SELECT COUNT(*) AS jumlah_barang,
                COALESCE(SUM(stok), 0) AS total_stok,
                COALESCE(SUM(harga * stok), 0) AS total_nilai
         FROM barang'
    )->fetch_assoc();

    return [
        'jumlah_barang' => (int) $hasil['jumlah_barang'],
        'total_stok' => (int) $hasil['total_stok'],
        'total_nilai' => (int) $hasil['total_nilai'],
    ];
}
