<?php

// Pencarian memakai prepared statement agar input aman.
function barang_semua(mysqli $koneksi, $keyword = '')
{
    if ($keyword !== '') {
        $cari = '%' . $keyword . '%';
        $stmt = $koneksi->prepare('SELECT * FROM barang WHERE kode LIKE ? OR nama LIKE ? OR kategori LIKE ? ORDER BY nama ASC');
        $stmt->bind_param('sss', $cari, $cari, $cari);
    } else {
        $stmt = $koneksi->prepare('SELECT * FROM barang ORDER BY nama ASC');
    }

    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $data;
}

function barang_terbaru(mysqli $koneksi, $batas = 5)
{
    $stmt = $koneksi->prepare('SELECT * FROM barang ORDER BY id DESC LIMIT ?');
    $stmt->bind_param('i', $batas);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $data;
}

function barang_cari_id(mysqli $koneksi, $id)
{
    $stmt = $koneksi->prepare('SELECT * FROM barang WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $barang = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $barang ?: null;
}

function barang_tambah(mysqli $koneksi, array $data)
{
    $kode = $data['kode'];
    $nama = $data['nama'];
    $kategori = $data['kategori'];
    $harga = (int) $data['harga'];
    $stok = (int) $data['stok'];

    try {
        $stmt = $koneksi->prepare('INSERT INTO barang (kode, nama, kategori, harga, stok) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('sssii', $kode, $nama, $kategori, $harga, $stok);
        $berhasil = $stmt->execute();
        $stmt->close();

        return $berhasil;
    } catch (mysqli_sql_exception $e) {
        return false;
    }
}

function barang_update(mysqli $koneksi, $id, array $data)
{
    $kode = $data['kode'];
    $nama = $data['nama'];
    $kategori = $data['kategori'];
    $harga = (int) $data['harga'];
    $stok = (int) $data['stok'];

    try {
        $stmt = $koneksi->prepare('UPDATE barang SET kode = ?, nama = ?, kategori = ?, harga = ?, stok = ? WHERE id = ?');
        $stmt->bind_param('sssiii', $kode, $nama, $kategori, $harga, $stok, $id);
        $berhasil = $stmt->execute();
        $stmt->close();

        return $berhasil;
    } catch (mysqli_sql_exception $e) {
        return false;
    }
}

function barang_hapus(mysqli $koneksi, $id)
{
    try {
        $stmt = $koneksi->prepare('DELETE FROM barang WHERE id = ?');
        $stmt->bind_param('i', $id);
        $berhasil = $stmt->execute();
        $stmt->close();

        return $berhasil;
    } catch (mysqli_sql_exception $e) {
        return false;
    }
}
