<?php

function validasi_login(array $data)
{
    $errors = [];
    $username = ambil_teks($data, 'username');
    $password = ambil_teks($data, 'password', false);

    if ($username === '') {
        $errors['username'] = 'Username wajib diisi.';
    }

    if ($password === '') {
        $errors['password'] = 'Password wajib diisi.';
    }

    return $errors;
}

function validasi_register(array $data, mysqli $koneksi)
{
    $errors = [];
    $nama = ambil_teks($data, 'nama');
    $username = ambil_teks($data, 'username');
    $password = ambil_teks($data, 'password', false);
    $konfirmasi = ambil_teks($data, 'konfirmasi', false);

    if ($nama === '') {
        $errors['nama'] = 'Nama wajib diisi.';
    } elseif (mb_strlen($nama) > 100) {
        $errors['nama'] = 'Nama maksimal 100 karakter.';
    }

    if ($username === '') {
        $errors['username'] = 'Username wajib diisi.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
        $errors['username'] = 'Username 3-50 karakter, hanya huruf, angka, dan garis bawah.';
    } else {
        $stmt = $koneksi->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();

        if ($stmt->get_result()->fetch_assoc() !== null) {
            $errors['username'] = 'Username sudah digunakan.';
        }

        $stmt->close();
    }

    if ($password === '') {
        $errors['password'] = 'Password wajib diisi.';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'Password minimal 8 karakter.';
    } elseif (strlen($password) > 72) {
        $errors['password'] = 'Password maksimal 72 karakter.';
    }

    if ($konfirmasi !== $password) {
        $errors['konfirmasi'] = 'Konfirmasi password tidak sama.';
    }

    return $errors;
}

function validasi_barang(array $data, mysqli $koneksi, $id = null)
{
    $errors = [];
    $kode = ambil_teks($data, 'kode');
    $nama = ambil_teks($data, 'nama');
    $kategori = ambil_teks($data, 'kategori');
    $harga = ambil_teks($data, 'harga');
    $stok = ambil_teks($data, 'stok');

    if ($kode === '') {
        $errors['kode'] = 'Kode barang wajib diisi.';
    } elseif (mb_strlen($kode) > 20) {
        $errors['kode'] = 'Kode maksimal 20 karakter.';
    } elseif (!preg_match('/^[a-zA-Z0-9._-]+$/', $kode)) {
        $errors['kode'] = 'Kode hanya boleh huruf, angka, titik, garis bawah, dan tanda hubung.';
    } elseif (kode_barang_dipakai($koneksi, $kode, $id)) {
        $errors['kode'] = 'Kode barang sudah digunakan.';
    }

    if ($nama === '') {
        $errors['nama'] = 'Nama barang wajib diisi.';
    } elseif (mb_strlen($nama) > 150) {
        $errors['nama'] = 'Nama maksimal 150 karakter.';
    }

    if ($kategori === '') {
        $errors['kategori'] = 'Kategori wajib diisi.';
    } elseif (mb_strlen($kategori) > 100) {
        $errors['kategori'] = 'Kategori maksimal 100 karakter.';
    }

    if ($harga === '') {
        $errors['harga'] = 'Harga wajib diisi.';
    } elseif (!preg_match('/^\d+$/', $harga)) {
        $errors['harga'] = 'Harga harus berupa angka bulat.';
    } elseif ((int) $harga > 2147483647) {
        $errors['harga'] = 'Harga terlalu besar.';
    }

    if ($stok === '') {
        $errors['stok'] = 'Stok wajib diisi.';
    } elseif (!preg_match('/^\d+$/', $stok)) {
        $errors['stok'] = 'Stok harus berupa angka bulat.';
    } elseif ((int) $stok > 2147483647) {
        $errors['stok'] = 'Stok terlalu besar.';
    }

    return $errors;
}

// Cek duplikat kode, abaikan data yang sedang diedit.
function kode_barang_dipakai(mysqli $koneksi, $kode, $id = null)
{
    if ($id !== null) {
        $stmt = $koneksi->prepare('SELECT id FROM barang WHERE kode = ? AND id <> ? LIMIT 1');
        $stmt->bind_param('si', $kode, $id);
    } else {
        $stmt = $koneksi->prepare('SELECT id FROM barang WHERE kode = ? LIMIT 1');
        $stmt->bind_param('s', $kode);
    }

    $stmt->execute();
    $dipakai = $stmt->get_result()->fetch_assoc() !== null;
    $stmt->close();

    return $dipakai;
}
