<?php

function e($teks)
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

function redirect($tujuan)
{
    header('Location: ' . $tujuan);
    exit;
}

function set_flash($tipe, $pesan)
{
    $_SESSION['flash'] = [
        'tipe' => $tipe,
        'pesan' => $pesan,
    ];
}

function tampilkan_flash()
{
    if (empty($_SESSION['flash'])) {
        return;
    }

    $tipe = in_array($_SESSION['flash']['tipe'], ['success', 'danger', 'warning', 'info'], true)
        ? $_SESSION['flash']['tipe']
        : 'info';
    $pesan = $_SESSION['flash']['pesan'];

    unset($_SESSION['flash']);

    echo '<div class="alert alert-' . $tipe . ' alert-dismissible fade show" role="alert">'
        . e($pesan)
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>'
        . '</div>';
}

function format_rupiah($angka)
{
    return 'Rp ' . number_format((float) $angka, 0, ',', '.');
}

function menu_aktif($file)
{
    return basename($_SERVER['PHP_SELF']) === $file ? 'active' : '';
}

function ambil_teks($data, $kunci, $trim = true)
{
    $nilai = isset($data[$kunci]) && is_string($data[$kunci]) ? $data[$kunci] : '';

    return $trim ? trim($nilai) : $nilai;
}

function ambil_id($nilai)
{
    if (!is_string($nilai) && !is_int($nilai)) {
        return null;
    }

    $nilai = trim((string) $nilai);

    if ($nilai === '') {
        return null;
    }

    $id = filter_var($nilai, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    return $id === false ? null : (int) $id;
}

// Token CSRF dipakai untuk semua form POST.
function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_valid()
{
    return isset($_POST['csrf_token'], $_SESSION['csrf_token'])
        && is_string($_POST['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}
