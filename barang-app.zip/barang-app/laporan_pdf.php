<?php

require __DIR__ . '/includes/init.php';

require_login();

require __DIR__ . '/lib/fpdf/fpdf.php';

// FPDF memakai encoding Latin-1, jadi teks UTF-8 dikonversi dulu.
function teks_pdf($teks)
{
    $hasil = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', (string) $teks);

    return $hasil !== false ? $hasil : (string) $teks;
}

function potong_teks($pdf, $teks, $lebar)
{
    $teks = teks_pdf($teks);
    $batas = $lebar - 2.5;

    if ($pdf->GetStringWidth($teks) <= $batas) {
        return $teks;
    }

    while ($teks !== '' && $pdf->GetStringWidth($teks . '...') > $batas) {
        $teks = substr($teks, 0, -1);
    }

    return $teks . '...';
}

class LaporanBarang extends FPDF
{
    public function Header()
    {
        $this->SetFont('Helvetica', 'B', 14);
        $this->Cell(0, 8, 'Laporan Data Barang', 0, 1, 'C');
        $this->SetFont('Helvetica', '', 9);
        $this->Cell(0, 5, 'Dicetak: ' . date('d-m-Y H:i'), 0, 1, 'C');
        $this->Ln(4);
    }

    public function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Helvetica', '', 8);
        $this->Cell(0, 10, 'Halaman ' . $this->PageNo(), 0, 0, 'C');
    }
}

$daftar = barang_semua($koneksi);
$ringkasan = hitung_ringkasan($koneksi);

$pdf = new LaporanBarang('L', 'mm', 'A4');
$pdf->SetMargins(15, 15, 15);
$pdf->SetAutoPageBreak(true, 20);
$pdf->SetTitle('Laporan Data Barang');
$pdf->AddPage();

$lebar = [12, 28, 90, 50, 30, 15, 42];
$judul_kolom = ['No', 'Kode', 'Nama', 'Kategori', 'Harga', 'Stok', 'Nilai'];
$rata = ['C', 'L', 'L', 'L', 'R', 'R', 'R'];

$pdf->SetFont('Helvetica', 'B', 8);
$pdf->SetFillColor(235, 237, 239);
$pdf->SetDrawColor(200, 205, 210);
$pdf->SetTextColor(33, 37, 41);

foreach ($judul_kolom as $i => $judul) {
    $pdf->Cell($lebar[$i], 7, $judul, 1, 0, 'C', true);
}
$pdf->Ln();

$pdf->SetFont('Helvetica', '', 8);
$nomor = 1;

foreach ($daftar as $barang) {
    $isi = [
        $nomor,
        potong_teks($pdf, $barang['kode'], $lebar[1]),
        potong_teks($pdf, $barang['nama'], $lebar[2]),
        potong_teks($pdf, $barang['kategori'], $lebar[3]),
        format_rupiah($barang['harga']),
        number_format((int) $barang['stok'], 0, ',', '.'),
        format_rupiah((int) $barang['harga'] * (int) $barang['stok']),
    ];

    $pdf->SetFillColor(248, 249, 250);

    foreach ($isi as $i => $teks) {
        $pdf->Cell($lebar[$i], 7, $teks, 1, 0, $rata[$i], $nomor % 2 === 0);
    }

    $pdf->Ln();
    $nomor++;
}

if (empty($daftar)) {
    $pdf->Cell(array_sum($lebar), 8, 'Belum ada data barang.', 1, 1, 'C');
}

$pdf->SetFont('Helvetica', 'B', 8);
$pdf->SetFillColor(235, 237, 239);
$pdf->Cell(12 + 28 + 90 + 50 + 30, 7, 'Total', 1, 0, 'R', true);
$pdf->Cell(15, 7, number_format($ringkasan['total_stok'], 0, ',', '.'), 1, 0, 'R', true);
$pdf->Cell(42, 7, format_rupiah($ringkasan['total_nilai']), 1, 1, 'R', true);

$pdf->Ln(4);
$pdf->SetFont('Helvetica', '', 9);
$pdf->Cell(0, 6, 'Jumlah jenis barang: ' . number_format($ringkasan['jumlah_barang'], 0, ',', '.'), 0, 1);

$pdf->Output('I', 'laporan-barang-' . date('Y-m-d') . '.pdf');
