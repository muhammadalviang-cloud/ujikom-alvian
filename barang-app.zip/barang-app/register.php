<?php

require __DIR__ . '/includes/init.php';

if (user_login() !== null) {
    redirect('dashboard.php');
}

$errors = [];
$data = [
    'nama' => '',
    'username' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        set_flash('danger', 'Sesi tidak valid atau sudah kedaluwarsa. Silakan coba lagi.');
        redirect('register.php');
    }

    $data['nama'] = ambil_teks($_POST, 'nama');
    $data['username'] = ambil_teks($_POST, 'username');
    $password = ambil_teks($_POST, 'password', false);

    $errors = validasi_register($_POST, $koneksi);

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $koneksi->prepare('INSERT INTO users (nama, username, password) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $data['nama'], $data['username'], $hash);
            $stmt->execute();
            $stmt->close();

            set_flash('success', 'Akun berhasil dibuat. Silakan masuk.');
            redirect('login.php');
        } catch (mysqli_sql_exception $e) {
            if ((int) $e->getCode() === 1062) {
                $errors['username'] = 'Username sudah digunakan.';
            } else {
                $errors['umum'] = 'Akun gagal disimpan. Silakan coba lagi.';
            }
        }
    }
}

$judul = 'Daftar';
$halaman_auth = true;
require __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
    <div class="col-12 col-sm-9 col-md-7 col-lg-5">
        <div class="text-center mb-4">
            <a href="index.php" class="text-decoration-none text-dark">
                <span class="h4 fw-semibold">Data Barang</span>
            </a>
            <p class="text-secondary small mb-0">Buat akun untuk mulai mengelola data.</p>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h5 mb-3">Daftar Akun</h1>

                <?php if (isset($errors['umum'])): ?>
                    <div class="alert alert-danger" role="alert"><?= e($errors['umum']) ?></div>
                <?php endif; ?>

                <form method="post" action="register.php" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama lengkap</label>
                        <input type="text" class="form-control<?= isset($errors['nama']) ? ' is-invalid' : '' ?>" id="nama" name="nama" value="<?= e($data['nama']) ?>" autocomplete="name" required autofocus>
                        <?php if (isset($errors['nama'])): ?>
                            <div class="invalid-feedback"><?= e($errors['nama']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control<?= isset($errors['username']) ? ' is-invalid' : '' ?>" id="username" name="username" value="<?= e($data['username']) ?>" autocomplete="username" required>
                        <?php if (isset($errors['username'])): ?>
                            <div class="invalid-feedback"><?= e($errors['username']) ?></div>
                        <?php else: ?>
                            <div class="form-text">3-50 karakter, hanya huruf, angka, dan garis bawah.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control<?= isset($errors['password']) ? ' is-invalid' : '' ?>" id="password" name="password" autocomplete="new-password" required>
                        <?php if (isset($errors['password'])): ?>
                            <div class="invalid-feedback"><?= e($errors['password']) ?></div>
                        <?php else: ?>
                            <div class="form-text">Minimal 8 karakter.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-4">
                        <label for="konfirmasi" class="form-label">Konfirmasi password</label>
                        <input type="password" class="form-control<?= isset($errors['konfirmasi']) ? ' is-invalid' : '' ?>" id="konfirmasi" name="konfirmasi" autocomplete="new-password" required>
                        <?php if (isset($errors['konfirmasi'])): ?>
                            <div class="invalid-feedback"><?= e($errors['konfirmasi']) ?></div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Daftar</button>
                </form>

                <p class="text-center text-secondary small mt-4 mb-0">
                    Sudah punya akun? <a href="login.php" class="text-decoration-none">Masuk</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
