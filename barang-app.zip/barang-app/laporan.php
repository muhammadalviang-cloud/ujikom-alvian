<?php

require __DIR__ . '/includes/init.php';

require_login();

$daftar = barang_semua($koneksi);
$ringkasan = hitung_ringkasan($koneksi);

$judul = 'Laporan';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
        <h1 class="h4 mb-1">Laporan Data Barang</h1>
        <p class="text-secondary mb-0">Rekap seluruh barang dan nilai persediaan.</p>
    </div>
    <a href="laporan_pdf.php" target="_blank" rel="noopener" class="btn btn-primary">Cetak PDF</a>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered align-middle mb-0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Kategori</th>
                        <th class="text-end">Harga</th>
                        <th class="text-end">Stok</th>
                        <th class="text-end">Nilai Stok</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($daftar)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">Belum ada data barang.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($daftar as $nomor => $barang): ?>
                            <tr>
                                <td><?= $nomor + 1 ?></td>
                                <td class="text-nowrap"><?= e($barang['kode']) ?></td>
                                <td><?= e($barang['nama']) ?></td>
                                <td><?= e($barang['kategori']) ?></td>
                                <td class="text-end text-nowrap"><?= format_rupiah($barang['harga']) ?></td>
                                <td class="text-end"><?= number_format((int) $barang['stok'], 0, ',', '.') ?></td>
                                <td class="text-end text-nowrap"><?= format_rupiah((int) $barang['harga'] * (int) $barang['stok']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr class="fw-semibold">
                        <td colspan="5" class="text-end">Total</td>
                        <td class="text-end"><?= number_format($ringkasan['total_stok'], 0, ',', '.') ?></td>
                        <td class="text-end text-nowrap"><?= format_rupiah($ringkasan['total_nilai']) ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="row g-3 mt-1">
            <div class="col-12 col-md-4">
                <div class="border rounded p-3">
                    <div class="stat-label mb-1">Jumlah Barang</div>
                    <div class="fw-semibold"><?= number_format($ringkasan['jumlah_barang'], 0, ',', '.') ?></div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="border rounded p-3">
                    <div class="stat-label mb-1">Total Stok</div>
                    <div class="fw-semibold"><?= number_format($ringkasan['total_stok'], 0, ',', '.') ?></div>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="border rounded p-3">
                    <div class="stat-label mb-1">Total Nilai</div>
                    <div class="fw-semibold"><?= format_rupiah($ringkasan['total_nilai']) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
