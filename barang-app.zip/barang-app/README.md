# Data Barang

Aplikasi CRUD data barang dengan PHP native dan MySQL.

## Menjalankan

1. Pastikan folder ini berada di `C:\xampp\htdocs\barang-app`.
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka phpMyAdmin, lalu impor file `database.sql`.
4. Buka `http://localhost/barang-app`.
5. Daftar akun baru melalui halaman registrasi, kemudian masuk.

Konfigurasi database ada di `config/koneksi.php`. Sesuaikan jika user atau password MySQL Anda berbeda.
